import UIKit

struct Point {
    var x: Double = 0
    var y: Double = 0
    var z: Double = 0
    var radius: Double = 0
    var angle: Double = 0
    
    init(x: Double, y: Double) {
        self.x = x
        self.y = y
        
        self.radius = sqrt(x*x + y*y)
        self.angle = atan(y/x)
    }
    
    init(radius: Double, angle: Double) {
        self.radius = radius
        self.angle = angle
        
        self.x = radius*cos(angle)
        self.y = radius*sin(angle)
    }
    
    init(x: Double, y: Double, z: Double) {
        self.x = x
        self.y = y
        self.z = z
    }
    
    mutating func movePoint(moveXTO: Double, moveYTo: Double) {
        self.x += moveXTO
        self.y += moveYTo
        
        self.radius = sqrt(x*x + y*y)
        self.angle = atan(y/x)
    }
    
    mutating func movePoint(moveRadiusTo: Double, moveAngleTo: Double) {
        self.radius += moveRadiusTo
        self.angle += moveAngleTo
        
        self.x = radius*cos(angle)
        self.y = radius*sin(angle)
    }
    
    func showDescartesPoint() {
        print("Descartes coordinates: x is \(self.x), y is \(self.y)")
    }
    
    func showPolarPoint() {
        print("Polar coordinates: radius is \(self.radius), angle is \(self.angle)")
    }
}

//var point = Point(x: 3, y: 4)
//
//let anotherPoint = Point(radius: 5, angle: 0.927)
//
//point.movePoint(moveXTO: 4, moveYTo: 5)
//
//point.movePoint(moveRadiusTo: 4, moveAngleTo: 0.5)
//
//point.showDescartesPoint()
//
//point.showPolarPoint()

extension Point {
    func distanceBetweenCoordinates() {
        print(fabs(self.x - self.y))
    }
}

//point.distanceBetweenCoordinates()

class Line {
    let beginning: Double
    let end: Double
    
    init(beginning: Double, end: Double) {
        let coordinates = Point(x: beginning, y: end)
        self.beginning = coordinates.x
        self.end = coordinates.y
    }
    
    func distanceBetweenCoordinates() {
        print("Distance between beginning and end of the line is \(fabs(self.end - self.beginning))")
    }
}

//let line = Line(beginning: 2, end: 8)
//
//line.distanceBetweenCoordinates()


class Triangle {
    let firstSide: Double
    let secondSide: Double
    let thirdSide: Double
    
    init(x1: Double, x2: Double, x3: Double, y1: Double, y2: Double, y3: Double, z1: Double, z2: Double, z3: Double) {
        
        let coordinatesOfFirstPoint = Point(x: x1, y: y1, z: z1)
        let coordinatesOfSecondPoint = Point(x: x2, y: y2, z: z2)
        let coordinatesOfThirdPoint = Point(x: x3, y: y3, z: z3)
        
        let aVector = (
            coordinatesOfFirstPoint.x - coordinatesOfSecondPoint.x, coordinatesOfFirstPoint.y - coordinatesOfSecondPoint.y, coordinatesOfFirstPoint.z - coordinatesOfSecondPoint.z
        )
        let bVector = (
            coordinatesOfFirstPoint.x - coordinatesOfThirdPoint.x, coordinatesOfFirstPoint.y - coordinatesOfThirdPoint.y, coordinatesOfFirstPoint.z - coordinatesOfThirdPoint.z
        )
        let cVector = (
            coordinatesOfSecondPoint.x - coordinatesOfThirdPoint.x, coordinatesOfSecondPoint.y - coordinatesOfThirdPoint.y, coordinatesOfSecondPoint.z - coordinatesOfThirdPoint.z
        )
        
        self.firstSide = fabs(sqrt((aVector.0 * aVector.0) + (aVector.1 * aVector.1) + (aVector.2 * aVector.2)))
        self.secondSide = fabs(sqrt((bVector.0 * bVector.0) + (bVector.1 * bVector.1) + (bVector.2 * bVector.2)))
        self.thirdSide = fabs(sqrt((cVector.0 * cVector.0) + (cVector.1 * cVector.1) + (cVector.2 * cVector.2)))
    }
    
    func perimeter() -> Double {
        let perimeter = firstSide + secondSide + thirdSide
        return perimeter
    }
    
    func area() -> Double {
        let halfPerimeter = self.perimeter() / 2
        
        let area = sqrt(halfPerimeter * fabs(halfPerimeter - firstSide) * fabs(halfPerimeter - secondSide) * fabs(halfPerimeter - thirdSide))
        
        return area
    }
}

let triangle = Triangle(x1: 3, x2: 5, x3: 6, y1: 3, y2: 25, y3: 10, z1: 4, z2: 100, z3: 2)

triangle.perimeter()
triangle.area()

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class Rectangle {
    var width: Double
    var height: Double
    
    init(x1: Double, x2: Double, x3: Double, y1: Double, y2: Double, y3: Double, z1: Double, z2: Double, z3: Double) {
        
        let coordinatesOfFirstPoint = Point(x: x1, y: y1, z: z1)
        let coordinatesOfSecondPoint = Point(x: x2, y: y2, z: z2)
        let coordinatesOfThirdPoint = Point(x: x3, y: y3, z: z3)
        
        let aVector = (
            coordinatesOfFirstPoint.x - coordinatesOfSecondPoint.x, coordinatesOfFirstPoint.y - coordinatesOfSecondPoint.y, coordinatesOfFirstPoint.z - coordinatesOfSecondPoint.z
        )
        let bVector = (
            coordinatesOfFirstPoint.x - coordinatesOfThirdPoint.x, coordinatesOfFirstPoint.y - coordinatesOfThirdPoint.y, coordinatesOfFirstPoint.z - coordinatesOfThirdPoint.z
        )
        
        self.width = fabs(sqrt((aVector.0 * aVector.0) + (aVector.1 * aVector.1) + (aVector.2 * aVector.2)))
        self.height = fabs(sqrt((bVector.0 * bVector.0) + (bVector.1 * bVector.1) + (bVector.2 * bVector.2)))
        
        if height > width {
            var value: Double
            value = height
            height = width
            width = value
        }
    }
    
    func perimeter() -> Double {
        let perimeter = 2.0 * (width + height)
        return perimeter
    }
    
    func area() -> Double {
        return width * height
    }
}

let rect = Rectangle(x1: 3, x2: 4, x3: 7, y1: 9, y2: 6, y3: 9, z1: 6, z2: 7, z3: 1)

rect.perimeter()
rect.area()


class Mathematics {
    var triangle: Triangle?
    var rectangle: Rectangle?
    var line: Line?
    
    init(triangle: Triangle) {
        self.triangle = triangle
        self.rectangle = nil
        self.line = nil
    }
    
    init(rectangle: Rectangle) {
        self.rectangle = rectangle
        self.triangle = nil
        self.line = nil
    }
    
    init(line: Line) {
        self.line = line
        self.triangle = nil
        self.rectangle = nil
    }
}


let figure = Mathematics(triangle: Triangle(x1: 3, x2: 7, x3: 8, y1: 6, y2: 5, y3: 9, z1: 7, z2: 9, z3: 6))
